from langchain_ollama import OllamaEmbeddings

#defina a frase para ser exibida
frase = "Eu sou mais do que você pode entender."

# Definir o modelo de emb.
embeddings = OllamaEmbeddings(model="hf.co/mixedbread-ai/mxbai-embed-large-v1:latest")
# Gera os vetores 
document_embeddings = embeddings.embed_documents(frase)
# Mostra o tamanho dos emb.
tamanhoEmbaddings = len(document_embeddings[0])

print(f"Quantidade dos embeddings: {tamanhoEmbaddings}")
 # Exibe um quantitativo dos valores vetoriais - 6 valores
print(f"Primeiros valores do embedding: {document_embeddings[0][:6]}")